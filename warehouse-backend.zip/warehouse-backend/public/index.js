const apiBase = 'http://localhost:3000';

async function fetchBin() {
    const binId = document.getElementById('binId').value.trim();
    if (!binId) return alert('Please enter a Bin ID');

    const res = await fetch(`${apiBase}/bin/${binId}`);
    const data = await res.json();

    if (res.ok) {
    document.getElementById('currentQtyOutput').textContent =
        `Current quantity in bin "${binId}": ${data.quantity}`;
    } else {
    document.getElementById('currentQtyOutput').textContent =
        `❌ Error: ${data.message || 'Could not fetch bin data.'}`;
    }
}

async function updateBin() {
    const binId = document.getElementById('binId').value.trim();
    const used = parseInt(document.getElementById('usedQty').value);

    if (!binId || isNaN(used) || used <= 0) {
    return alert('Please enter valid bin ID and used quantity.');
    }

    const res = await fetch(`${apiBase}/bin/${binId}/update`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ used })
    });

    const data = await res.json();

    if (res.ok) {
    document.getElementById('updateResultOutput').textContent =
        `✅ Updated! New quantity: ${data.newQuantity}`;
    document.getElementById('usedQty').value = '';
    } else {
    document.getElementById('updateResultOutput').textContent =
        `❌ Error: ${data.message || 'Could not update bin.'}`;
    }
}