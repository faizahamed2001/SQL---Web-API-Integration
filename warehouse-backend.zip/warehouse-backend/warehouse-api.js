// warehouse-api.js

const express = require('express');
const sql = require('mssql');
const app = express();
const port = 3000;
const path = require('path');

app.use(express.json()); // for parsing JSON body

console.log('🔧 Starting Warehouse API...');

// ===========================
// 🔧 SQL Server Configuration
// ===========================
const config = {
    user: 'sa',
    password: 'root',
    server: '127.0.0.1', // e.g., localhost or IP - 192.168.31.166
    database: 'TRYME',
    options: {
    encrypt: true,
    trustServerCertificate: true
  }
};

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Define the root route to serve 'index.html'
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


// ========================
// 🚀 GET bin item quantity
// ========================
app.get('/bin/:id', async (req, res) => {
  const binId = req.params.id;

  try {
    const pool = await sql.connect(config);
    const result = await pool
      .request()
      .input('binId', sql.VarChar, binId)
      .query('SELECT SUM(IN_QTY-OUT_QTY) "Total_Items", LOC_ID, ITEM_CODE FROM INV_BIN_TRN WHERE ITEM_CODE = @binId GROUP BY ITEM_CODE, LOC_ID');
      

    if (result.recordset.length === 0) {
      return res.status(404).json({ message: 'Bin not found' });
    }

    // const quantity = result.recordset[0].IN_QTY;
    const quantity = result.recordset[0].Total_Items;
    console.log(quantity)
    res.json({ binId, quantity });
  } catch (err) {
    console.error('Error fetching bin:', err);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// =======================================
// 🔄 POST to update bin after consumption
// =======================================
app.post('/bin/:id/update', async (req, res) => {
  const binId = req.params.id;
  const { used } = req.body; // e.g., { "used": 5 }

  if (typeof used !== 'number' || used <= 0) {
    return res.status(400).json({ message: 'Invalid used value' });
  }

  try {
    const pool = await sql.connect(config);

    // Reduce quantity
    const updateResult = await pool
      .request()
      .input('binId', sql.VarChar, binId)
      .input('used', sql.Int, used)
      .query(`
        UPDATE INV_BIN_TRN
        SET OUT_QTY = @used
        WHERE ITEM_CODE = @binId
      `);

    if (updateResult.rowsAffected[0] === 0) {
      return res.status(404).json({ message: 'Bin not found or nothing updated' });
    }

    // Fetch new quantity
    const newResult = await pool
      .request()
      .input('binId', sql.VarChar, binId)
      .query('SELECT SUM(IN_QTY-OUT_QTY) "Total_Items" FROM INV_BIN_TRN WHERE ITEM_CODE = @binId');

    res.json({
      message: 'Bin updated successfully',
      binId,
      newQuantity: newResult.recordset[0].Total_Items
    });
  } catch (err) {
    console.error('Error updating bin:', err);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// ====================
// 🌐 Start the server
// ====================
app.listen(port, () => {
  console.log(`🚀 Warehouse API server running at http://localhost:${port}`);
});
