// Required dependencies
const express = require('express');
const sql = require('mssql');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

// Express app setup
const app = express();
app.use(cors());
app.use(bodyParser.json());

// SQL Server config
const dbConfig = {
    user: 'sa',
    password: 'root',
    server: '127.0.0.1',
    database: 'TRYME',
    options: {
        encrypt: true,
        trustServerCertificate: true
    }
};

// Database pool (global)
let pool;

// Connect to DB
sql.connect(dbConfig).then(p => {
    pool = p;
    console.log("Connected to SQL Server");
}).catch(err => {
    console.error("DB Connection Error:", err);
});

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Define the root route to serve 'index.html'
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// GET bin item summary
app.get('/api/bin/:binCode', async (req, res) => {
    const binCode = req.params.binCode;
    console.log("Requested bin:", binCode);

    try {
        if (!pool) {
            return res.status(500).send('Database not connected');
        }

        // Step 1: Get LOC_ID from FullBinCode
        const locIdResult = await pool.request()
            .input('binCode', sql.VarChar, binCode)
            .query(`SELECT LOC_ID FROM INV_RACK_LOCATION_MST WHERE FullBinCode = @binCode`);
        
        if (locIdResult.recordset.length === 0) {
            return res.status(404).send('Bin not found');
        }

        const locId = locIdResult.recordset[0].LOC_ID;
        console.log('LOC_ID:', locId);

        // Step 2: Get latest inventory summary for that LOC_ID
        const result = await pool.request()
            .input('locId', sql.Int, locId)
            .query(`
                WITH FirstInQty AS (
                                    SELECT 
                                        ITEM_CODE,
                                        IN_QTY,
                                        ROW_NUMBER() OVER (PARTITION BY ITEM_CODE ORDER BY CREATED_DATE ASC) AS rn
                                    FROM INV_BIN_TRN
                                    WHERE LOC_ID = @locId
                                    ),
                                    TotalOutQty AS (
                                        SELECT 
                                            ITEM_CODE,
                                            SUM(OUT_QTY) AS total_out_qty
                                        FROM INV_BIN_TRN
                                        WHERE LOC_ID = @locId
                                        GROUP BY ITEM_CODE
                                    )
                                    SELECT 
                                        f.ITEM_CODE,
                                        (f.IN_QTY - ISNULL(t.total_out_qty, 0)) AS total_quantity
                                    FROM 
                                        FirstInQty f
                                    LEFT JOIN 
                                        TotalOutQty t
                                    ON 
                                        f.ITEM_CODE = t.ITEM_CODE
                                    WHERE 
                                        f.rn = 1;
        `);

        console.log('Items:', result.recordset);
        res.json(result.recordset);

    } catch (err) {
        console.error(err);
        res.status(500).send('Error fetching bin details');
    }
});

app.post('/api/bin/pick', async (req, res) => {
    const { bin_id, item_code, out_quantity, action_by } = req.body;
  
    if (!bin_id || !item_code || !out_quantity || !action_by) {
      return res.status(400).send('Missing required fields');
    }
  
    try {
      if (!pool) {
        return res.status(500).send('Database not connected');
      }
  
      const transaction = new sql.Transaction(pool);
      await transaction.begin();
  
      // Step 1: Get LOC_ID
      const locRequest = new sql.Request(transaction);
      const locResult = await locRequest
        .input('bin_id', sql.VarChar, bin_id)
        .query(`SELECT TOP 1 LOC_ID FROM INV_RACK_LOCATION_MST WHERE FullBinCode = @bin_id`);
  
      if (locResult.recordset.length === 0) {
        await transaction.rollback();
        return res.status(404).send('Bin not found');
      }
      const locId = locResult.recordset[0].LOC_ID;
  
      // Step 2: Get latest available quantity
      const qtyRequest = new sql.Request(transaction);
      const stockResult = await qtyRequest
        .input('locId', sql.Int, locId)
        .input('item_code', sql.VarChar, item_code)
        .query(`
          WITH LatestRow AS (
            SELECT *, ROW_NUMBER() OVER (PARTITION BY ITEM_CODE ORDER BY CREATED_DATE DESC) AS rn
            FROM INV_BIN_TRN
            WHERE LOC_ID = @locId AND ITEM_CODE = @item_code
          )
          SELECT 
            (MAX(CASE WHEN rn = 1 THEN IN_QTY END) - MAX(CASE WHEN rn = 1 THEN OUT_QTY END)) AS available_qty
          FROM LatestRow
        `);
  
      const availableQty = stockResult.recordset[0].available_qty ?? 0;
  
      if (out_quantity > availableQty) {
        await transaction.rollback();
        return res.status(400).send(`Not enough stock. Available: ${availableQty}`);
      }
  
      // Step 3: Get new BIN_NUM
      const binNumRequest = new sql.Request(transaction);
      const binNumResult = await binNumRequest.query(`SELECT COALESCE(MAX(BIN_NUM), 0) + 1 AS new_bin_num FROM INV_BIN_TRN`);
      const newBinNum = binNumResult.recordset[0].new_bin_num;
  
      // Step 4: Insert pick transaction
      const insertRequest = new sql.Request(transaction);
      await insertRequest
        .input('bin_num', sql.Int, newBinNum)
        .input('loc_id', sql.Int, locId)
        .input('item_code', sql.VarChar, item_code)
        .input('in_qty', sql.Int, availableQty)
        .input('out_qty', sql.Int, out_quantity)
        .input('action_by', sql.VarChar, action_by)
        .query(`
          INSERT INTO INV_BIN_TRN (
            BIN_NUM, SL_NUM, TRN_MODE, LOC_ID, SOURCE_TRN_ID, SOURCE_DOC_TYPE, SOURCE_DOC_NUM,
            ITEM_CODE, IN_QTY, OUT_QTY, CREATED_DATE, CREATED_BY, PC_NAME
          ) VALUES (
            @bin_num, 1, 'ADJ', @loc_id, 0, 'ADJ', 0,
            @item_code, @in_qty, @out_qty, GETDATE(), @action_by, 'DESKTOP-AQESRB3'
          )
        `);
  
      await transaction.commit();
      res.send('Pick recorded and inventory updated');
  
    } catch (err) {
      console.error(err);
      res.status(500).send('Error updating inventory');
    }
  });
  

// app.post('/api/bin/pick', async (req, res) => {
//     const { bin_id, item_code, out_quantity, action_by } = req.body;

//     if (!bin_id || !item_code || !out_quantity || !action_by) {
//         return res.status(400).send('Missing required fields');
//     }

//     try {
//         if (!pool) {
//             return res.status(500).send('Database not connected');
//         }

//         const transaction = new sql.Transaction(pool);
//         await transaction.begin();

//         // Step 1: New request for LOC_ID
//         const locRequest = new sql.Request(transaction);
//         const locResult = await locRequest
//             .input('bin_id', sql.VarChar, bin_id)
//             .query(`SELECT TOP 1 LOC_ID FROM INV_RACK_LOCATION_MST WHERE FullBinCode = @bin_id`);
        
//         if (locResult.recordset.length === 0) {
//             await transaction.rollback();
//             return res.status(404).send('Bin not found');
//         }
//         const locId = locResult.recordset[0].LOC_ID;

//         // Step 2: New request for latest IN_QTY
//         const qtyRequest = new sql.Request(transaction);
//         const inQtyResult = await qtyRequest
//             .input('item_code', sql.VarChar, item_code)
//             .query(`SELECT TOP 1 IN_QTY FROM INV_BIN_TRN WHERE ITEM_CODE = @item_code ORDER BY CREATED_DATE DESC`);

//         const latestInQty = inQtyResult.recordset.length > 0 ? inQtyResult.recordset[0].IN_QTY : 0;

//         // Step 3: New request for BIN_NUM
//         const binNumRequest = new sql.Request(transaction);
//         const binNumResult = await binNumRequest
//             .query(`SELECT COALESCE(MAX(BIN_NUM), 0) + 1 AS new_bin_num FROM INV_BIN_TRN`);

//         const newBinNum = binNumResult.recordset[0].new_bin_num;

//         // Step 4: Final request to INSERT
//         const insertRequest = new sql.Request(transaction);
//         await insertRequest
//             .input('bin_num', sql.Int, newBinNum)
//             .input('loc_id', sql.Int, locId)
//             .input('item_code', sql.VarChar, item_code)
//             .input('in_qty', sql.Int, latestInQty)
//             .input('out_qty', sql.Int, out_quantity)
//             .input('action_by', sql.VarChar, action_by)
//             .query(`
//                 INSERT INTO INV_BIN_TRN (
//                     BIN_NUM, SL_NUM, TRN_MODE, LOC_ID, SOURCE_TRN_ID, SOURCE_DOC_TYPE, SOURCE_DOC_NUM,
//                     ITEM_CODE, IN_QTY, OUT_QTY, CREATED_DATE, CREATED_BY, PC_NAME
//                 ) VALUES (
//                     @bin_num, 1, 'ADJ', @loc_id, 0, 'ADJ', 0,
//                     @item_code, @in_qty, @out_qty, GETDATE(), @action_by, 'DESKTOP-AQESRB3'
//                 )
//             `);

//         await transaction.commit();
//         res.send('Pick recorded and inventory updated');

//     } catch (err) {
//         console.error(err);
//         res.status(500).send('Error updating inventory');
//     }
// });


// Start server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Warehouse API running on port ${PORT}`);
});
