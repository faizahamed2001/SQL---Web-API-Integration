const sql = require('mssql');

// Configuration object
// const config = {
//   user: 'DESKTOP-AQESRB3\Admin',
//   password: 'Faizaha@2351',
//   server: "192.168.31.166", // or '192.168.31.166' if connecting remotely
//   database: 'TRYME',
//   options: {
//     encrypt: true, // Use true if you're on Azure or need encryption
//     trustServerCertificate: true // Set to true for self-signed certificates
//   }
// };

const config = {
    user: 'sa',
    password: 'root',
    server: "127.0.0.1", // or '192.168.31.166' if connecting remotely
    database: 'TRYME',
    options: {
      encrypt: true, // Use true if you're on Azure or need encryption
      trustServerCertificate: true // Set to true for self-signed certificates
    }
  };

// Function to test the connection
async function testConnection() {
  try {
    // Connect to the database
    await sql.connect(config);
    console.log('✅ Connected to SQL Server successfully.');

    // Execute a simple query
    const result = await sql.query('SELECT 1 AS number');
    console.log('Query result:', result.recordset);

    // Close the connection
    await sql.close();
  } catch (err) {
    console.error('❌ Connection failed:', err);
  }
}

// Run the test
testConnection();
