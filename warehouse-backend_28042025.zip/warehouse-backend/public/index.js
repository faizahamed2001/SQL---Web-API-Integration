// const apiBase = 'http://localhost:3000';

// async function fetchBin() {
//     const binId = document.getElementById('binId').value.trim();
//     if (!binId) return alert('Please enter a Bin ID');

//     const res = await fetch(`${apiBase}/bin/${binId}`);
//     const data = await res.json();

//     if (res.ok) {
//     document.getElementById('currentQtyOutput').textContent =
//         `Current quantity in bin "${binId}": ${data.quantity}`;
//     } else {
//     document.getElementById('currentQtyOutput').textContent =
//         `❌ Error: ${data.message || 'Could not fetch bin data.'}`;
//     }
// }

// async function updateBin() {
//     const binId = document.getElementById('binId').value.trim();
//     const used = parseInt(document.getElementById('usedQty').value);

//     if (!binId || isNaN(used) || used <= 0) {
//     return alert('Please enter valid bin ID and used quantity.');
//     }

//     const res = await fetch(`${apiBase}/bin/${binId}/update`, {
//     method: 'POST',
//     headers: { 'Content-Type': 'application/json' },
//     body: JSON.stringify({ used })
//     });

//     const data = await res.json();

//     if (res.ok) {
//     document.getElementById('updateResultOutput').textContent =
//         `✅ Updated! New quantity: ${data.newQuantity}`;
//     document.getElementById('usedQty').value = '';
//     } else {
//     document.getElementById('updateResultOutput').textContent =
//         `❌ Error: ${data.message || 'Could not update bin.'}`;
//     }
// }

let selectedItems = []; 

async function loadBin() {
  const binCode = document.getElementById('binCode').value;
  const res = await fetch(`http://localhost:3000/api/bin/${binCode}`);
  const data = await res.json();

  const itemsContainer = document.getElementById('items');
  itemsContainer.innerHTML = '';
  selectedItems = [];
  document.getElementById('pickSection').style.display = 'none';

  data.forEach(item => {
    const div = document.createElement('div');
    div.className = 'item';
    div.textContent = `Item: ${item.ITEM_CODE} | Qty: ${item.total_quantity}`;

    div.onclick = () => {
      if (div.classList.contains('active')) {
        div.classList.remove('active');
        selectedItems = selectedItems.filter(i => i.ITEM_CODE !== item.ITEM_CODE);
      } else {
        div.classList.add('active');
        selectedItems.push(item);
      }

      document.getElementById('pickSection').style.display = selectedItems.length > 0 ? 'block' : 'none';
    };

    itemsContainer.appendChild(div);
  });
}

async function submitPick() {
  const binCode = document.getElementById('binCode').value;
  const outQtyInput = document.getElementById('outQty').value;
  const outQty = parseInt(outQtyInput);

  if (selectedItems.length === 0 || !outQtyInput) {
    return alert('Select at least one item and enter quantity.');
  }

  if (isNaN(outQty) || outQty <= 0) {
    return alert('Please enter a quantity greater than 0.');
  }

  // ❗ Check if trying to pick more than available quantity
  const invalidItem = selectedItems.find(item => outQty > item.total_quantity);
  if (invalidItem) {
    return alert(`Cannot pick ${outQty} from item ${invalidItem.ITEM_CODE}. Available quantity: ${invalidItem.total_quantity}`);
  }

  const promises = selectedItems.map(item => {
    const payload = {
      bin_id: binCode,
      item_code: item.ITEM_CODE,
      out_quantity: outQty,
      action_by: "User1"
    };

    return fetch('http://localhost:3000/api/bin/pick', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
  });

  await Promise.all(promises);

  alert('All picks recorded.');
  await loadBin();
  document.getElementById('outQty').value = '';
}
